package com.example.personalizedvacancynotifier;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class view_application_history extends AppCompatActivity implements AdapterView.OnItemClickListener {
    ListView lv;

String [] vaccancyid,candidate_id,designation,salary,status,termsandcondition,company;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_application_history);
        lv=(ListView) findViewById(R.id.L1);

        lv.setOnItemClickListener(this);

        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String url = sh.getString("url","")+"and_view_application_history_post";

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObj = new JSONObject(response);
                            if (jsonObj.getString("status").equalsIgnoreCase("ok")) {

                                JSONArray js = jsonObj.getJSONArray("data");//from python

                                vaccancyid = new String[js.length()];
                                candidate_id = new String[js.length()];
                                designation = new String[js.length()];
                                salary = new String[js.length()];
                                status = new String[js.length()];
                                termsandcondition = new String[js.length()];
                                company = new String[js.length()];


                                for (int i = 0; i < js.length(); i++) {
                                    JSONObject u = js.getJSONObject(i);
                                    vaccancyid[i] = u.getString("vaccancyid");//dbcolumn name in double quotes
                                    candidate_id[i] = u.getString("candidate_id");
                                    designation[i] = u.getString("designation");
                                    salary[i] = u.getString("salary");
                                    status[i] = u.getString("status");
                                    termsandcondition[i] = u.getString("termsandcondition");
                                    company[i] = u.getString("name");
                                }
                                lv.setAdapter(new custom_view_application_history(getApplicationContext(),vaccancyid,candidate_id,designation,salary,status,termsandcondition,company));


                            } else {
                                Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                            }

                        } catch (Exception e) {
                            Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {

            //                value Passing android to python
            @Override
            protected Map<String, String> getParams() {
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                Map<String, String> params = new HashMap<String, String>();

                params.put("lid",sh.getString("lid",""));
                return params;
            }
        };


        int MY_SOCKET_TIMEOUT_MS = 100000;

        postRequest.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(postRequest);

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
     //   final CharSequence[] options = {  "Joining Letters","Cancel" };
//
//        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
//        SharedPreferences.Editor ed = sh.edit();
//        ed.putString("cand_id", candidate_id[i]);
//        ed.commit();
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(view_application_history.this);
//        builder.setTitle("More Options");
//        builder.setItems(options, new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int item) {
//                if (options[item].equals("Joining Letters"))
//                {
//
//                    Intent ij=new Intent(getApplicationContext(),view_joining_letter.class);
//                    startActivity(ij);
//                }
////                if (options[item].equals("Test results"))
////                {
////
////                    Intent ij=new Intent(getApplicationContext(),view_mock_test_result.class);
////                    startActivity(ij);
////                }
//                else if (options[item].equals("Cancel")) {
//                    dialog.dismiss();
//                }
//            }
//        });
//        builder.show();
    }
}