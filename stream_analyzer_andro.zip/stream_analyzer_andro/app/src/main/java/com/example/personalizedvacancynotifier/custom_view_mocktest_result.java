package com.example.personalizedvacancynotifier;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class custom_view_mocktest_result extends BaseAdapter {

    String[] resultid, company, designation, date, markscored;
    private Context context;

    public custom_view_mocktest_result(Context appcontext, String[] resultid1, String[] date, String[] designation, String[] markscored, String[] company) {
        this.context = appcontext;
        this.resultid = resultid1;
        this.company = company;
        this.designation = designation;
        this.date = date;
        this.markscored = markscored;


    }

    @Override
    public int getCount() {
        return resultid.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if (view == null) {
            gridView = new View(context);
            //gridView=inflator.inflate(R.layout.customview, null);
            gridView = inflator.inflate(R.layout.activity_custom_view_mocktest_result, null);

        } else {
            gridView = (View) view;

        }


        TextView t = (TextView) gridView.findViewById(R.id.textView62);
        TextView t1 = (TextView) gridView.findViewById(R.id.textView63);
        TextView t2 = (TextView) gridView.findViewById(R.id.textView69);
        TextView t3 = (TextView) gridView.findViewById(R.id.textView77);

        t.setTextColor(Color.BLACK);
        t1.setTextColor(Color.BLACK);
        t2.setTextColor(Color.BLACK);
        t3.setTextColor(Color.BLACK);

        t.setText(resultid[i]);
        t1.setText(date[i]);
        t2.setText(designation[i]);
        t3.setText(markscored[i]+"/"+company[i]);
        return gridView;


    }
}