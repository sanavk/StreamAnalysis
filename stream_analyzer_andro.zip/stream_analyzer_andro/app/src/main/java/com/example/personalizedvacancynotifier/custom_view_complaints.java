package com.example.personalizedvacancynotifier;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class custom_view_complaints extends BaseAdapter {

    String[] complaintid, date, userid, complaint, replay, status;
    private Context context;

    public custom_view_complaints(Context appcontext, String[] complaintid1, String[] date1, String[] userid1, String[] complaint1, String[] replay1, String[] status1) {
        this.context = appcontext;
        this.complaintid = complaintid1;
        this.date = date1;
        this.userid = userid1;
        this.complaint = complaint1;
        this.replay = replay1;
        this.status = status1;


    }

    @Override
    public int getCount() {
        return complaintid.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if (view == null) {
            gridView = new View(context);
            //gridView=inflator.inflate(R.layout.customview, null);
            gridView = inflator.inflate(R.layout.activity_custom_view_complaints, null);

        } else {
            gridView = (View) view;

        }
        TextView t = (TextView) gridView.findViewById(R.id.textView38);
        TextView t1 = (TextView) gridView.findViewById(R.id.textView39);
        TextView t2 = (TextView) gridView.findViewById(R.id.textView37);


        t.setTextColor(Color.BLACK);
        t1.setTextColor(Color.BLACK);
        t2.setTextColor(Color.BLACK);


        t.setText(complaint[i]);
        t1.setText(replay[i]);
        t2.setText(date[i]);

        return gridView;


    }
}