package com.example.personalizedvacancynotifier;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import com.example.personalizedvacancynotifier.databinding.ActivityAgencyHomeBinding;

public class Agency_home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityAgencyHomeBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityAgencyHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarAgencyHome.toolbar);
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
                .setOpenableLayout(drawer)
                .build();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.agency_home, menu);
        return true;
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.nav_profile)
        {
            Intent i = new Intent(getApplicationContext(),viewprofile_agency.class);
            startActivity(i);
        }
        else if(id==R.id.nav_logout)
        {
            startActivity(new Intent(getApplicationContext(),login.class));
        }
        else if (id==R.id.nav_skilles)
        {
            startActivity(new Intent(getApplicationContext(),My_skill.class));

        }

        else if (id==R.id.nav_my_cand)
        {
            startActivity(new Intent(getApplicationContext(),view_students_cand.class));

        }
        else if (id==R.id.navusers)
        {
            startActivity(new Intent(getApplicationContext(),view_students_staff.class));

        }
//        else if (id==R.id.nav_myskill)
//        {
//            startActivity(new Intent(getApplicationContext(),My_skill.class));
//
//        }
//        else if (id==R.id.nav_ex)
//        {
//            startActivity(new Intent(getApplicationContext(),My_experience.class));
//
//        }
//        else if (id==R.id.nav_myqual)
//        {
//            startActivity(new Intent(getApplicationContext(),My_academic_qual.class));
//
//        }
//        else if (id==R.id.nav_exams)
//        {
//            startActivity(new Intent(getApplicationContext(),Viewexams.class));
//
//        }

        return true;
    }
}