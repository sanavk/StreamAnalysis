package com.example.personalizedvacancynotifier;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Attendexam extends AppCompatActivity {

    String [] exq_id,question,optiona,optionb,optionc,optiond,answer;
    TextView tvquestion;
    RadioButton rda,rdb,rdc,rdd;
    Button btn;

    int mark=0;

    int curquestionindex=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendexam);

        tvquestion=(TextView) findViewById(R.id.textView28);
        rda=(RadioButton) findViewById(R.id.radioButton8);
        rdb=(RadioButton) findViewById(R.id.radioButton7);
        rdc=(RadioButton) findViewById(R.id.radioButton6);
        rdd=(RadioButton) findViewById(R.id.radioButton5);

        btn=(Button) findViewById(R.id.button6);


        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String url = sh.getString("url","")+"and_view_exam_questions";

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObj = new JSONObject(response);
                            if (jsonObj.getString("status").equalsIgnoreCase("ok")) {

                                JSONArray js = jsonObj.getJSONArray("data");//from python
                                exq_id = new String[js.length()];
                                question = new String[js.length()];
                                optiona = new String[js.length()];
                                optionb = new String[js.length()];
                                optionc = new String[js.length()];
                                optiond = new String[js.length()];
                                answer = new String[js.length()];

                                for (int i = 0; i < js.length(); i++) {
                                    JSONObject u = js.getJSONObject(i);
                                    exq_id[i] = u.getString("questionid");
                                    question[i] = u.getString("question");
                                    optiona[i] = u.getString("optiona");
                                    optionb[i] = u.getString("optionb");
                                    optionc[i] = u.getString("optionc");
                                    optiond[i] = u.getString("optiond");
                                    answer[i] = u.getString("correctanswer");

                                }

                                if(exq_id.length>0)
                                {
                                    tvquestion.setText(question[0]);
                                    rda.setText(optiona[0]);
                                    rdb.setText(optionb[0]);
                                    rdc.setText(optionb[0]);
                                    rdd.setText(optiond[0]);
                                }

                            } else {
                                Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                            }

                        } catch (Exception e) {
                            Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {

            //                value Passing android to python
            @Override
            protected Map<String, String> getParams() {
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                Map<String, String> params = new HashMap<String, String>();

                params.put("ex_id",sh.getString("ssid",""));
                return params;
            }
        };


        int MY_SOCKET_TIMEOUT_MS = 100000;

        postRequest.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(postRequest);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String result="";
                if(rda.isChecked())
                {
                    result=rda.getText().toString();
                }
                else if(rdb.isChecked())
                {
                    result=rdb.getText().toString();
                }
                else if(rdc.isChecked())
                {
                    result=rdc.getText().toString();
                }
                else if(rdd.isChecked())
                {
                    result=rdd.getText().toString();
                }

                if(result.equalsIgnoreCase(answer[curquestionindex]))
                {

                    mark=mark+1;

                }

                curquestionindex=curquestionindex+1;
                if(curquestionindex<answer.length)
                {
                    tvquestion.setText(question[0]);
                    rda.setText(optiona[curquestionindex]);
                    rdb.setText(optionb[curquestionindex]);
                    rdc.setText(optionb[curquestionindex]);
                    rdd.setText(optiond[curquestionindex]);

                }
                else
                {

                    SharedPreferences sh=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    String url = sh.getString("url", "") + "save_result";


                    RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                    StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                                    try {
                                        JSONObject jsonObj = new JSONObject(response);
                                        if (jsonObj.getString("status").equalsIgnoreCase("ok")) {

                                            Toast.makeText(getApplicationContext(),"Result saved successfully",Toast.LENGTH_LONG).show();
                                            Intent ins= new Intent(getApplicationContext(),Home.class);
                                            startActivity(ins);

                                        }
                                        else
                                        {
                                            Toast.makeText(getApplicationContext(),"Failed to save result",Toast.LENGTH_LONG).show();
                                        }
//

                                    } catch (Exception e) {
                                        Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    // error
                                    Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                                }
                            }
                    ) {

                        //                value Passing android to python
                        @Override
                        protected Map<String, String> getParams() {
                            SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                            Map<String, String> params = new HashMap<String, String>();

                            params.put("exam_id",
                                    sh.getString("ssid",""));//passing to python
                            params.put("lid", sh.getString("lid",""));
                            params.put("mark", mark+"");
                            params.put("lid",sh.getString("lid",""));


                            return params;
                        }
                    };


                    int MY_SOCKET_TIMEOUT_MS = 100000;

                    postRequest.setRetryPolicy(new DefaultRetryPolicy(
                            MY_SOCKET_TIMEOUT_MS,
                            DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                    requestQueue.add(postRequest);


                }



            }
        });



    }
}