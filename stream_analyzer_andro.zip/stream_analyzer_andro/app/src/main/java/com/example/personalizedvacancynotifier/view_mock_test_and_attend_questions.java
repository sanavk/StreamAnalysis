package com.example.personalizedvacancynotifier;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class view_mock_test_and_attend_questions extends AppCompatActivity {
    ListView lv;
String[]testid,title,cid,date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_mock_test_and_attend_questions);
        lv=(ListView) findViewById(R.id.L4);
    }
}