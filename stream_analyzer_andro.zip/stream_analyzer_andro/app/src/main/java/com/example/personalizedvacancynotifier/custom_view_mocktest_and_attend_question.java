package com.example.personalizedvacancynotifier;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

public class custom_view_mocktest_and_attend_question extends BaseAdapter {

    String[] testid,title,cid,date;
    private Context context;

    public custom_view_mocktest_and_attend_question(Context appcontext, String[] testid1, String[] title1, String[] cid1,String[]date1) {
        this.context = appcontext;
        this.testid = testid1;
        this.title = title1;
        this.cid = cid1;
        this.date = date1;



    }

    @Override
    public int getCount() {
        return testid.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if (view == null) {
            gridView = new View(context);
            //gridView=inflator.inflate(R.layout.customview, null);
            gridView = inflator.inflate(R.layout.activity_custom_view_mocktest_and_attend_question, null);

        } else {
            gridView = (View) view;

        }
        TextView t = (TextView) gridView.findViewById(R.id.textView58);
        TextView t1 = (TextView) gridView.findViewById(R.id.textView59);

        Button btn=(Button) gridView.findViewById(R.id.button7);

        t.setTextColor(Color.BLACK);
        t1.setTextColor(Color.BLACK);


        t.setText(title[i]);
        t1.setText(date[i]);


        return gridView;


    }

}