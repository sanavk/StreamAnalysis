package com.example.personalizedvacancynotifier;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class custom_view_personalized_job_vaccancie extends BaseAdapter {
    String[]vaccancyid,designation,description,no_ofpost,salary,applybefore,status,cid,termsandcondition;

    private Context context;

    public custom_view_personalized_job_vaccancie(Context appcontext,String[]vaccancyid1,String[]designation1,String[]description1,String[]no_ofpost1,String[]salary1,String[]applybefore1,String[]status1,String[]cid1,String[]termsandcondition1)
    {
        this.context=appcontext;
        this.vaccancyid=vaccancyid1;
        this.designation=designation1;
        this.description=description1;
        this.no_ofpost=no_ofpost1;
        this.salary=salary1;
        this.applybefore=applybefore1;
        this.status=status1;
        this.cid=cid1;
        this.termsandcondition=termsandcondition1;




    }

    @Override
    public int getCount() {
        return vaccancyid.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflator=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if(view==null)
        {
            gridView=new View(context);
            //gridView=inflator.inflate(R.layout.customview, null);
            gridView=inflator.inflate(R.layout.activity_custom_view_personalized_job_vaccancie,null);

        }
        else
        {
            gridView=(View)view;

        }
        TextView t=(TextView) gridView.findViewById(R.id.textView46);
        TextView t1=(TextView) gridView.findViewById(R.id.textView45);
        TextView t2=(TextView) gridView.findViewById(R.id.textView47);
        TextView t3=(TextView) gridView.findViewById(R.id.textView48);
        TextView t4=(TextView) gridView.findViewById(R.id.textView49);
        TextView t5=(TextView) gridView.findViewById(R.id.textView50);

        Button btn=(Button) gridView.findViewById(R.id.button6);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
                String url = sh.getString("url", "") + "and_apply_for_vaccancy_post";


                RequestQueue requestQueue = Volley.newRequestQueue(context.getApplicationContext());
                StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                                // response
                                try {
                                    JSONObject jsonObj = new JSONObject(response);
                                    if (jsonObj.getString("status").equalsIgnoreCase("ok")) {


                                        Toast.makeText(context.getApplicationContext(), "SUCCESSFUL", Toast.LENGTH_SHORT).show();

                                    }


                                    // }
                                    else {
                                        Toast.makeText(context.getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                                    }

                                } catch (Exception e) {
                                    Toast.makeText(context.getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // error
                                Toast.makeText(context.getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams() {
                        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
                        Map<String, String> params = new HashMap<String, String>();

//                    String id=sh.getString("uid","");
                        params.put("ulid", "lid");
                        params.put("vaccancyid",vaccancyid[i]);

                        return params;
                    }
                };

                int MY_SOCKET_TIMEOUT_MS = 100000;

                postRequest.setRetryPolicy(new DefaultRetryPolicy(
                        MY_SOCKET_TIMEOUT_MS,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                requestQueue.add(postRequest);





            }
        });

        t.setTextColor(Color.BLACK);
        t1.setTextColor(Color.BLACK);
        t2.setTextColor(Color.BLACK);
        t3.setTextColor(Color.BLACK);
        t4.setTextColor(Color.BLACK);
        t5.setTextColor(Color.BLACK);


        t.setText(designation[i]);
        t1.setText(description[i]);
        t2.setText(no_ofpost[i]);
        t3.setText(salary[i]);
        t4.setText(applybefore[i]);
        t5.setText(termsandcondition[i]);


        return gridView;

    }


}
