package com.example.personalizedvacancynotifier;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class custom_view_student_counc extends BaseAdapter  {
    String[]name,place,post,pin,estyear,website,logo,email,phone,lid;

    private Context context;

    public custom_view_student_counc(Context appcontext, String[]name1, String[]place1, String[]post1, String[]pin1, String[]estyear1, String[]website1, String[]logo1, String[]email1, String[]phone1, String[]lid1)
    {
        this.context=appcontext;
        this.name=name1;
        this.place=place1;
        this.post=post1;
        this.pin=pin1;
        this.estyear=estyear1;
        this.website=website1;
        this.logo=logo1;
        this.email=email1;
        this.phone=phone1;
        this.lid=lid1;



    }

    @Override
    public int getCount() {
        return lid.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflator=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if(view==null)
        {
            gridView=new View(context);
            //gridView=inflator.inflate(R.layout.customview, null);
            gridView=inflator.inflate(R.layout.activity_custom_view_student_new_counc,null);

        }
        else
        {
            gridView=(View)view;

        }
        TextView t=(TextView) gridView.findViewById(R.id.textView24);
//        TextView t1=(TextView) gridView.findViewById(R.id.textView25);
//        TextView t2=(TextView) gridView.findViewById(R.id.textView26);
//        TextView t3=(TextView) gridView.findViewById(R.id.textView27);
//        TextView t4=(TextView) gridView.findViewById(R.id.textView28);
        TextView t5=(TextView) gridView.findViewById(R.id.textView29);
        TextView t6=(TextView) gridView.findViewById(R.id.textView30);
        TextView t7=(TextView) gridView.findViewById(R.id.textView31);

        ImageView img =(ImageView) gridView.findViewById(R.id.imageView3);
        Button btn=(Button) gridView.findViewById(R.id.button5);
        btn.setTag(i);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int ij=Integer.parseInt(view.getTag().toString());
                SharedPreferences sh=PreferenceManager.getDefaultSharedPreferences(context);
                SharedPreferences.Editor ed = sh.edit();
                ed.putString("mtoid",lid[ij]);
                ed.putString("mname",name[ij]);
                ed.putString("mtype","counc");
                ed.commit();
                Intent in = new Intent(context.getApplicationContext(),Test_counc.class);
                in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(in);
            }
        });



        Button btn1=(Button) gridView.findViewById(R.id.button8);
        btn1.setTag(i);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int ij=Integer.parseInt(view.getTag().toString());
                SharedPreferences sh=PreferenceManager.getDefaultSharedPreferences(context);
                SharedPreferences.Editor ed = sh.edit();
                ed.putString("mtoid",lid[ij]);
                ed.putString("mname",name[ij]);
                ed.putString("mtype","counc");
                ed.commit();
                Intent in = new Intent(context.getApplicationContext(),view_mock_test_result.class);
                in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(in);
            }
        });



        Button btn2=(Button) gridView.findViewById(R.id.button9);
        btn2.setTag(i);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
          final       int ij=Integer.parseInt(view.getTag().toString());
//                SharedPreferences sh=PreferenceManager.getDefaultSharedPreferences(context);
//                SharedPreferences.Editor ed = sh.edit();
//                ed.putString("mtoid",lid[ij]);
//                ed.putString("mname",name[ij]);
//                ed.putString("mtype","counc");
//                ed.commit();
//                Intent in = new Intent(context.getApplicationContext(),view_mock_test_result.class);
//                in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                context.startActivity(in);


                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
                String url = sh.getString("url", "") + "add_cand";


                RequestQueue requestQueue = Volley.newRequestQueue(context.getApplicationContext());
                StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                                // response
                                try {
                                    JSONObject jsonObj = new JSONObject(response);
                                    if (jsonObj.getString("status").equalsIgnoreCase("ok")) {


                                        Toast.makeText(context.getApplicationContext(), "SUCCESSFUL", Toast.LENGTH_SHORT).show();
                                        Intent in = new Intent(context.getApplicationContext(),view_students_staff.class);
                in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(in);

                                    }


                                    // }
                                    else {
                                        Toast.makeText(context.getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                                    }

                                } catch (Exception e) {
                                    Toast.makeText(context.getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // error
                                Toast.makeText(context.getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams() {
                        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
                        Map<String, String> params = new HashMap<String, String>();

//                    String id=sh.getString("uid","");
                        params.put("agency_lid", sh.getString("lid",""));
                        params.put("id",lid[ij]);
params.put("course_id",website[ij]);
                        return params;
                    }
                };

                int MY_SOCKET_TIMEOUT_MS = 100000;

                postRequest.setRetryPolicy(new DefaultRetryPolicy(
                        MY_SOCKET_TIMEOUT_MS,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                requestQueue.add(postRequest);






            }
        });





        t.setTextColor(Color.BLACK);
//        t1.setTextColor(Color.BLACK);
//        t2.setTextColor(Color.BLACK);
//        t3.setTextColor(Color.BLACK);
//        t4.setTextColor(Color.BLACK);
        t5.setTextColor(Color.BLACK);
        t6.setTextColor(Color.BLACK);
        t7.setTextColor(Color.BLACK);


        t.setText(name[i]);
//        t1.setText(place[i]);
//        t2.setText(pin[i]);
//        t3.setText(post[i]);
//        t4.setText(estyear[i]);
        t5.setText(pin[i]);
        t6.setText(email[i]);
        t7.setText(phone[i]);








        SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(context);
        String ip=sh.getString("ip","");
        String url="http://" + ip + ":5050"+logo[i];


        Picasso.with(context).load(url).into(img);

        return gridView;

    }


}