package com.example.personalizedvacancynotifier;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class custom_view_application_history extends BaseAdapter {
String[]vaccancyid,candidate_id,designation,salary,status,termsandcondition,company;
    private Context context;

    public custom_view_application_history(Context appcontext,String[]candidateid1,String[]vaccancyid1,String[]userid1,String[]appliedon1,String[]tc,String[]status1,String[]company)

    {
        this.context=appcontext;
        this.candidate_id=candidateid1;
        this.vaccancyid=vaccancyid1;
        this.designation=userid1;
        this.salary=appliedon1;
        this.status=status1;
        this.termsandcondition=tc;
        this.company=company;




    }

    @Override
    public int getCount() {
        return company.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflator=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if(view==null)
        {
            gridView=new View(context);
            //gridView=inflator.inflate(R.layout.customview, null);
            gridView=inflator.inflate(R.layout.activity_custom_view_application_history,null);

        }
        else
        {
            gridView=(View)view;

        }
        TextView t=(TextView) gridView.findViewById(R.id.textView53);
        TextView t1=(TextView) gridView.findViewById(R.id.textView54);
        TextView t2=(TextView) gridView.findViewById(R.id.textView55);

        TextView t3=(TextView) gridView.findViewById(R.id.textView25);
        TextView t4=(TextView) gridView.findViewById(R.id.textView26);


        t.setTextColor(Color.BLACK);
        t1.setTextColor(Color.BLACK);
        t2.setTextColor(Color.BLACK);
        t3.setTextColor(Color.BLACK);
        t4.setTextColor(Color.BLACK);


        t.setText(company[i]);
        t1.setText(designation[i]);
        t2.setText(salary[i]);
        t3.setText(termsandcondition[i]);
        t4.setText(status[i]);

        return gridView;



    }



}