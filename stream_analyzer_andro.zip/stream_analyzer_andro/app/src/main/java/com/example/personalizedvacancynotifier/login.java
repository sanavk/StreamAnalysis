package com.example.personalizedvacancynotifier;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class login extends AppCompatActivity implements View.OnClickListener {
    EditText ed1, ed2;
    Button btn;
    TextView tv,t1,t2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ed1 = (EditText) findViewById(R.id.editTextTextPersonName);
        ed2 = (EditText) findViewById(R.id.editTextTextPersonName2);
        btn = (Button) findViewById(R.id.button);
        btn.setOnClickListener(this);
        tv  = (TextView) findViewById(R.id.textView);
        tv.setOnClickListener(this);
        t1  = (TextView) findViewById(R.id.textView70);
        t1.setOnClickListener(this);
        t2  = (TextView) findViewById(R.id.textView71);
        t2.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view==tv) {
        Intent in = new Intent(getApplicationContext(),signup_student.class);
        startActivity(in);
        }
        if(view==t1) {
            Intent in = new Intent(getApplicationContext(),signup.class);
            startActivity(in);
        }
        if(view==t2) {
            Intent in = new Intent(getApplicationContext(),signup_counc.class);
            startActivity(in);
        }


        else if(view==btn){
        String eduser = ed1.getText().toString();
        String edpwd = ed2.getText().toString();
        if (eduser.length() == 0) {
            ed1.setError("Missing");

        } else if (edpwd.length() == 0) {
            ed2.setError("Missing");
        } else {

            SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            String url = sh.getString("url", "") + "and_login_post";

            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                            // response
                            try {
                                JSONObject jsonObj = new JSONObject(response);
                                if (jsonObj.getString("status").equalsIgnoreCase("ok")) {
                                    SharedPreferences.Editor ed = sh.edit();
                                    ed.putString("lid",jsonObj.getString("lid"));
                                    ed.putString("type",jsonObj.getString("type"));

                                    ed.commit();
if(jsonObj.getString("type").equalsIgnoreCase("student")) {

    Intent i = new Intent(getApplicationContext(), Home.class);
    startActivity(i);
}
else if(jsonObj.getString("type").equalsIgnoreCase("agency")) {

    Intent i = new Intent(getApplicationContext(), Agency_home.class);
    startActivity(i);
}
else {

        Intent i = new Intent(getApplicationContext(), Counsellor_home.class);
        startActivity(i);


}

                                }


                                // }
                                else {
                                    Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                                }

                            } catch (Exception e) {
                                Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    Map<String, String> params = new HashMap<String, String>();

//                    String id=sh.getString("uid","");
                    params.put("username", eduser);
                    params.put("password", edpwd);

                    return params;
                }
            };

            int MY_SOCKET_TIMEOUT_MS = 100000;

            postRequest.setRetryPolicy(new DefaultRetryPolicy(
                    MY_SOCKET_TIMEOUT_MS,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            requestQueue.add(postRequest);


        }
        }
    }
}