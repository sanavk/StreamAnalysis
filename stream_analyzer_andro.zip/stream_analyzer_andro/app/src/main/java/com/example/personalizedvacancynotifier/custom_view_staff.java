package com.example.personalizedvacancynotifier;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class custom_view_staff extends BaseAdapter  {
    String[]name,place,post,pin,estyear,website,logo,email,phone,lid;

    private Context context;

    public custom_view_staff(Context appcontext, String[]name1, String[]place1, String[]post1, String[]pin1, String[]estyear1, String[]website1, String[]logo1, String[]email1, String[]phone1, String[]lid1)
    {
        this.context=appcontext;
        this.name=name1;
        this.place=place1;
        this.post=post1;
        this.pin=pin1;
        this.estyear=estyear1;
        this.website=website1;
        this.logo=logo1;
        this.email=email1;
        this.phone=phone1;
        this.lid=lid1;



    }

    @Override
    public int getCount() {
        return lid.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflator=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if(view==null)
        {
            gridView=new View(context);
            //gridView=inflator.inflate(R.layout.customview, null);
            gridView=inflator.inflate(R.layout.activity_custom_view_counc_new,null);

        }
        else
        {
            gridView=(View)view;

        }
        TextView t=(TextView) gridView.findViewById(R.id.textView24);
//        TextView t1=(TextView) gridView.findViewById(R.id.textView25);
//        TextView t2=(TextView) gridView.findViewById(R.id.textView26);
//        TextView t3=(TextView) gridView.findViewById(R.id.textView27);
//        TextView t4=(TextView) gridView.findViewById(R.id.textView28);
        TextView t5=(TextView) gridView.findViewById(R.id.textView29);
        TextView t6=(TextView) gridView.findViewById(R.id.textView30);
        TextView t7=(TextView) gridView.findViewById(R.id.textView31);

        ImageView img =(ImageView) gridView.findViewById(R.id.imageView3);
        Button btn=(Button) gridView.findViewById(R.id.button5);
        btn.setTag(i);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int ij=Integer.parseInt(view.getTag().toString());
                SharedPreferences sh=PreferenceManager.getDefaultSharedPreferences(context);
                SharedPreferences.Editor ed = sh.edit();
                ed.putString("mtoid",lid[ij]);
                ed.putString("mname",name[ij]);
                ed.putString("mtype","counc");
                ed.commit();
                Intent in = new Intent(context.getApplicationContext(),Test.class);
                in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(in);
            }
        });
        t.setTextColor(Color.BLACK);
//        t1.setTextColor(Color.BLACK);
//        t2.setTextColor(Color.BLACK);
//        t3.setTextColor(Color.BLACK);
//        t4.setTextColor(Color.BLACK);
        t5.setTextColor(Color.BLACK);
        t6.setTextColor(Color.BLACK);
        t7.setTextColor(Color.BLACK);


        t.setText(name[i]);
//        t1.setText(place[i]);
//        t2.setText(pin[i]);
//        t3.setText(post[i]);
//        t4.setText(estyear[i]);
        t5.setText(pin[i]);
        t6.setText(email[i]);
        t7.setText(phone[i]);








        SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(context);
        String ip=sh.getString("ip","");
        String url="http://" + ip + ":5050"+logo[i];


        Picasso.with(context).load(url).into(img);

        return gridView;

    }


}