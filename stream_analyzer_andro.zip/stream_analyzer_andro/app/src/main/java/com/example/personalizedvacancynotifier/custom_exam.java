package com.example.personalizedvacancynotifier;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class custom_exam extends BaseAdapter {
    String[] ex_id,subject,date,time,jobid;
    private Context context;
    public custom_exam(Context applicationContext, String[] ex_id,String[] subject,String[] date,String[] time,String[] jobid) {
        this.context = applicationContext;
        this.ex_id = ex_id;
        this.subject = subject;
        this.date = date;
        this.time = time;
        this.jobid = jobid;

    }
    @Override
    public int getCount() {
        return ex_id.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflator=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View gridView;
        if(view==null)
        {
            gridView=new View(context);
            gridView=inflator.inflate(R.layout.custom_exam,null);//same class name
        }
        else
        {
            gridView=(View)view;
        }
        TextView tvsubject=(TextView)gridView.findViewById(R.id.textView10);
        TextView tvdate=(TextView)gridView.findViewById(R.id.textView11);
        TextView tvtime=(TextView)gridView.findViewById(R.id.textView20);


        tvsubject.setText(subject[i]);
        tvdate.setText(date[i]);
        tvtime.setText(time[i]);




        return gridView;
    }
}
