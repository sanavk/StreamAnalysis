package com.example.personalizedvacancynotifier;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ipset extends AppCompatActivity implements View.OnClickListener {
    EditText ed;
    Button btn;
    SharedPreferences sh;
    String ip,url;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ipset);
        ed=(EditText) findViewById(R.id.editTextTextPersonName3);

        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        btn=(Button) findViewById(R.id.button2);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        String ipval=ed.getText().toString();
        if(ipval.length()==0){
            ed.setError("Miising");
        }
        else{

            url = "http://"+ipval+":5050/";

            SharedPreferences.Editor ed = sh.edit();
            ed.putString("url",url);
            ed.putString("ip",ipval);
            ed.commit();

            Intent in = new Intent(getApplicationContext(),login.class);
            startActivity(in);




        }
    }


}
