package com.example.personalizedvacancynotifier;

import android.content.Context;

public class Custom_view_visited_game {
    public Custom_view_visited_game(Context applicationContext, String[] name, Object p2) {
    }
}
