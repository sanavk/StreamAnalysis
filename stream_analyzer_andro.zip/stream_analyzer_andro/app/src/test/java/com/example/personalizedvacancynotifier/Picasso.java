package com.example.personalizedvacancynotifier;

public class Picasso {
}
